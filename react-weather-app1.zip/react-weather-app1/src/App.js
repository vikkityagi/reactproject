import React, { useState } from 'react';
import axios from 'axios';
import SearchBar from './components/SearchBar';
import WeatherDisplay from './components/WeatherDisplay';
import './App.css';

const App = () => {
  const [weather, setWeather] = useState(null);

  const fetchWeather = async (city) => {
    try {
      const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=2fef41d71a80d0b3d49cd2fb39b95aa6`
      );
      setWeather(response.data);
    } catch (error) {
      console.error('Error fetching the weather data:', error);
      setWeather(null);
    }
    console.log('fw'+fetchWeather)
    console.log('w',weather)
  };

  return (
    <div className="App">
      <h1>Weather App</h1>
      <SearchBar onSearch={fetchWeather} />
      <WeatherDisplay weather={weather} />
    </div>
  );
};

export default App;
